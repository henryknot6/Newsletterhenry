# Ejercicio 1 : Newsletter

---

- Nombre:Henry Mendoza Medina
- Número de Control:22151453

---

## 📌 Descripción
Realizar una pagina web de suscripcion destacando
el uso de inputs y botones usando estos requerimientos.
Requerimientos:
Incluir un ícono que indique la finalidad de la página.
Incluir un campo de entrada para que los usuarios escriban su correo electrónico.
Incluir un botón para enviar el formulario.
Mantener un diseño limpio, con espaciado y tipografía adecuada.
Aplicar sombra (box-shadow) en los elementos (puedes usar el valor proporcionado o uno propio)
---

## 🚀 Tecnologías utilizadas
- HTML  
- CSS  
- Otro: 

---

## 🔗 Enlace al proyecto
Repositorio en GitHub: [Pega aquí tu enlace]  
Deploy: [Pega aquí el deploy de GitHub Pages]
---

## 📝 Reflexión
Aprendi en como se estructura la pagina de suscripcion y lo que me costo due las relaciones semanticas que se tienen que aplicar y conmo se debe dividir para darle la forma que debe tener.
